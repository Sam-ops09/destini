class Story {
  late String storyTitle;
  late String choice1;
  late String choice2;

  Story({required this.storyTitle,required this.choice1,required this.choice2}){
    this.storyTitle;
    this.choice1;
    this.choice2;
  }
}
